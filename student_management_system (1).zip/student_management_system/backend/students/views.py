from django.db.models import Q
from rest_framework import viewsets

from .models import Student
from .serializers import StudentSerializer


class StudentViewSet(viewsets.ModelViewSet):
    """
    Full CRUD for Student records.

    Supports optional query params on the list endpoint:
      ?search=<text>       matches roll number or name (case-insensitive)
      ?department=<code>   exact match, e.g. CSE
      ?year=<1-4>          exact match
    """

    serializer_class = StudentSerializer
    queryset = Student.objects.all()

    def get_queryset(self):
        queryset = Student.objects.all()
        params = self.request.query_params

        search = params.get("search")
        if search:
            queryset = queryset.filter(
                Q(name__icontains=search) | Q(roll_number__icontains=search)
            )

        department = params.get("department")
        if department:
            queryset = queryset.filter(department=department)

        year = params.get("year")
        if year:
            queryset = queryset.filter(year=year)

        return queryset
