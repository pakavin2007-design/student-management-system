from django.core.validators import RegexValidator
from django.db import models


class Student(models.Model):
    class Department(models.TextChoices):
        CSE = "CSE", "Computer Science & Engineering"
        ECE = "ECE", "Electronics & Communication Engineering"
        EEE = "EEE", "Electrical & Electronics Engineering"
        MECH = "MECH", "Mechanical Engineering"
        CIVIL = "CIVIL", "Civil Engineering"
        IT = "IT", "Information Technology"

    class Year(models.IntegerChoices):
        FIRST = 1, "1st Year"
        SECOND = 2, "2nd Year"
        THIRD = 3, "3rd Year"
        FOURTH = 4, "4th Year"

    phone_validator = RegexValidator(
        regex=r"^\d{10}$",
        message="Phone number must be exactly 10 digits.",
    )

    roll_number = models.CharField(max_length=20, unique=True)
    name = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    department = models.CharField(max_length=10, choices=Department.choices)
    year = models.IntegerField(choices=Year.choices)
    phone_number = models.CharField(max_length=10, validators=[phone_validator])
    address = models.CharField(max_length=255, blank=True, default="")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["roll_number"]

    def __str__(self):
        return f"{self.roll_number} - {self.name}"
