from rest_framework import status
from rest_framework.test import APITestCase

from .models import Student


class StudentAPITests(APITestCase):
    def setUp(self):
        self.list_url = "/api/students/"
        self.valid_payload = {
            "roll_number": "21CSE045",
            "name": "Ananya Sharma",
            "email": "ananya@example.com",
            "phone_number": "9876543210",
            "department": "CSE",
            "year": 2,
            "address": "Hostel C",
        }

    def test_create_student(self):
        response = self.client.post(self.list_url, self.valid_payload, format="json")
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(Student.objects.count(), 1)

    def test_duplicate_roll_number_rejected(self):
        self.client.post(self.list_url, self.valid_payload, format="json")
        response = self.client.post(self.list_url, self.valid_payload, format="json")
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn("roll_number", response.data)

    def test_invalid_phone_number_rejected(self):
        payload = {**self.valid_payload, "roll_number": "21CSE046", "phone_number": "12345"}
        response = self.client.post(self.list_url, payload, format="json")
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn("phone_number", response.data)

    def test_list_and_retrieve(self):
        create_resp = self.client.post(self.list_url, self.valid_payload, format="json")
        student_id = create_resp.data["id"]

        list_resp = self.client.get(self.list_url)
        self.assertEqual(list_resp.status_code, status.HTTP_200_OK)
        self.assertEqual(len(list_resp.data), 1)

        detail_resp = self.client.get(f"{self.list_url}{student_id}/")
        self.assertEqual(detail_resp.status_code, status.HTTP_200_OK)
        self.assertEqual(detail_resp.data["roll_number"], "21CSE045")

    def test_update_student(self):
        create_resp = self.client.post(self.list_url, self.valid_payload, format="json")
        student_id = create_resp.data["id"]

        updated_payload = {**self.valid_payload, "year": 3}
        update_resp = self.client.put(f"{self.list_url}{student_id}/", updated_payload, format="json")
        self.assertEqual(update_resp.status_code, status.HTTP_200_OK)
        self.assertEqual(update_resp.data["year"], 3)

    def test_delete_student(self):
        create_resp = self.client.post(self.list_url, self.valid_payload, format="json")
        student_id = create_resp.data["id"]

        delete_resp = self.client.delete(f"{self.list_url}{student_id}/")
        self.assertEqual(delete_resp.status_code, status.HTTP_204_NO_CONTENT)
        self.assertEqual(Student.objects.count(), 0)

    def test_search_filter(self):
        self.client.post(self.list_url, self.valid_payload, format="json")
        second_payload = {
            "roll_number": "21ECE010",
            "name": "Ravi Kumar",
            "email": "ravi@example.com",
            "phone_number": "9123456780",
            "department": "ECE",
            "year": 1,
        }
        self.client.post(self.list_url, second_payload, format="json")

        response = self.client.get(self.list_url, {"department": "ECE"})
        self.assertEqual(len(response.data), 1)
        self.assertEqual(response.data[0]["roll_number"], "21ECE010")

        response = self.client.get(self.list_url, {"search": "ananya"})
        self.assertEqual(len(response.data), 1)
        self.assertEqual(response.data[0]["name"], "Ananya Sharma")
