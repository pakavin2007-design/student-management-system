import re

from rest_framework import serializers

from .models import Student


class StudentSerializer(serializers.ModelSerializer):
    department_display = serializers.CharField(source="get_department_display", read_only=True)
    year_display = serializers.CharField(source="get_year_display", read_only=True)

    class Meta:
        model = Student
        fields = [
            "id",
            "roll_number",
            "name",
            "email",
            "department",
            "department_display",
            "year",
            "year_display",
            "phone_number",
            "address",
            "created_at",
            "updated_at",
        ]
        read_only_fields = ["id", "created_at", "updated_at"]

    def validate_roll_number(self, value):
        value = value.strip().upper()
        if not value:
            raise serializers.ValidationError("Roll number cannot be blank.")
        return value

    def validate_name(self, value):
        value = value.strip()
        if len(value) < 2:
            raise serializers.ValidationError("Name must be at least 2 characters long.")
        if not re.match(r"^[A-Za-z .'-]+$", value):
            raise serializers.ValidationError("Name may only contain letters, spaces, and . ' -")
        return value

    def validate_phone_number(self, value):
        if not re.match(r"^\d{10}$", value):
            raise serializers.ValidationError("Phone number must be exactly 10 digits.")
        return value
