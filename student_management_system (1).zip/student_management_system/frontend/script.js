(() => {
  "use strict";

  const API_BASE = "/api/students/";

  const DEPARTMENTS = [
    ["CSE", "Computer Science & Engineering"],
    ["ECE", "Electronics & Communication Engineering"],
    ["EEE", "Electrical & Electronics Engineering"],
    ["MECH", "Mechanical Engineering"],
    ["CIVIL", "Civil Engineering"],
    ["IT", "Information Technology"],
  ];

  const YEARS = [
    [1, "1st Year"],
    [2, "2nd Year"],
    [3, "3rd Year"],
    [4, "4th Year"],
  ];

  const FIELD_IDS = ["roll_number", "name", "email", "phone_number", "department", "year", "address"];

  // ---- element references ----
  const el = {
    searchInput: document.getElementById("search-input"),
    departmentFilter: document.getElementById("department-filter"),
    yearFilter: document.getElementById("year-filter"),
    addBtn: document.getElementById("add-student-btn"),
    banner: document.getElementById("banner"),
    rosterBody: document.getElementById("roster-body"),
    emptyState: document.getElementById("empty-state"),
    loadingState: document.getElementById("loading-state"),
    statTotal: document.getElementById("stat-total"),
    statDepartments: document.getElementById("stat-departments"),

    modalOverlay: document.getElementById("modal-overlay"),
    modalTitle: document.getElementById("modal-title"),
    modalClose: document.getElementById("modal-close"),
    form: document.getElementById("student-form"),
    studentIdField: document.getElementById("student-id"),
    cancelBtn: document.getElementById("cancel-btn"),
    departmentSelect: document.getElementById("f-department"),
    yearSelect: document.getElementById("f-year"),

    confirmOverlay: document.getElementById("confirm-overlay"),
    confirmBody: document.getElementById("confirm-body"),
    confirmCancel: document.getElementById("confirm-cancel"),
    confirmDelete: document.getElementById("confirm-delete"),
  };

  let bannerTimeout = null;
  let pendingDeleteId = null;
  let searchDebounce = null;

  // ---- setup ----

  function populateSelect(select, options, withAllOption) {
    select.innerHTML = "";
    if (withAllOption) {
      const opt = document.createElement("option");
      opt.value = "";
      opt.textContent = "All";
      select.appendChild(opt);
    }
    for (const [value, label] of options) {
      const opt = document.createElement("option");
      opt.value = value;
      opt.textContent = label;
      select.appendChild(opt);
    }
  }

  function departmentLabel(code) {
    const match = DEPARTMENTS.find(([value]) => value === code);
    return match ? match[1] : code;
  }

  function yearLabel(value) {
    const match = YEARS.find(([v]) => String(v) === String(value));
    return match ? match[1] : `Year ${value}`;
  }

  function init() {
    populateSelect(el.departmentFilter, DEPARTMENTS, true);
    populateSelect(el.yearFilter, YEARS, true);
    populateSelect(el.departmentSelect, DEPARTMENTS, false);
    populateSelect(el.yearSelect, YEARS, false);

    el.addBtn.addEventListener("click", () => openModal("add"));
    el.modalClose.addEventListener("click", closeModal);
    el.cancelBtn.addEventListener("click", closeModal);
    el.modalOverlay.addEventListener("click", (e) => {
      if (e.target === el.modalOverlay) closeModal();
    });

    el.confirmCancel.addEventListener("click", closeConfirm);
    el.confirmOverlay.addEventListener("click", (e) => {
      if (e.target === el.confirmOverlay) closeConfirm();
    });
    el.confirmDelete.addEventListener("click", performDelete);

    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape") {
        closeModal();
        closeConfirm();
      }
    });

    el.form.addEventListener("submit", handleSubmit);

    el.searchInput.addEventListener("input", () => {
      clearTimeout(searchDebounce);
      searchDebounce = setTimeout(fetchStudents, 300);
    });
    el.departmentFilter.addEventListener("change", fetchStudents);
    el.yearFilter.addEventListener("change", fetchStudents);

    fetchStudents();
  }

  // ---- data fetching ----

  function buildQuery() {
    const params = new URLSearchParams();
    if (el.searchInput.value.trim()) params.set("search", el.searchInput.value.trim());
    if (el.departmentFilter.value) params.set("department", el.departmentFilter.value);
    if (el.yearFilter.value) params.set("year", el.yearFilter.value);
    const qs = params.toString();
    return qs ? `${API_BASE}?${qs}` : API_BASE;
  }

  async function fetchStudents() {
    setLoading(true);
    try {
      const response = await fetch(buildQuery());
      if (!response.ok) throw new Error(`Server responded ${response.status}`);
      const data = await response.json();
      const students = Array.isArray(data) ? data : data.results || [];
      renderTable(students);
      updateStats(students);
    } catch (err) {
      showBanner("error", "Couldn't load student records. Is the backend running?");
      renderTable([]);
    } finally {
      setLoading(false);
    }
  }

  function setLoading(isLoading) {
    el.loadingState.hidden = !isLoading;
    if (isLoading) el.emptyState.hidden = true;
  }

  // ---- rendering ----

  function renderTable(students) {
    el.rosterBody.innerHTML = "";

    if (students.length === 0) {
      el.emptyState.hidden = false;
      return;
    }
    el.emptyState.hidden = true;

    for (const student of students) {
      const tr = document.createElement("tr");

      tr.innerHTML = `
        <td>${escapeHtml(student.roll_number)}</td>
        <td>${escapeHtml(student.name)}</td>
        <td>${escapeHtml(student.email)}</td>
        <td><span class="dept-tag">${escapeHtml(student.department)}</span></td>
        <td>${escapeHtml(yearLabel(student.year))}</td>
        <td>${escapeHtml(student.phone_number)}</td>
        <td class="col-actions">
          <button type="button" class="btn--text" data-action="edit">Edit</button>
          <button type="button" class="btn--text is-danger" data-action="delete">Delete</button>
        </td>
      `;

      tr.querySelector('[data-action="edit"]').addEventListener("click", () => openModal("edit", student));
      tr.querySelector('[data-action="delete"]').addEventListener("click", () => openConfirm(student));

      el.rosterBody.appendChild(tr);
    }
  }

  function updateStats(students) {
    el.statTotal.textContent = students.length;
    const departments = new Set(students.map((s) => s.department));
    el.statDepartments.textContent = departments.size;
  }

  function escapeHtml(value) {
    const div = document.createElement("div");
    div.textContent = value || "";
    return div.innerHTML;
  }

  // ---- modal: add / edit ----

  function openModal(mode, student) {
    clearFormErrors();
    el.form.reset();

    if (mode === "edit" && student) {
      el.modalTitle.textContent = "Edit student";
      el.studentIdField.value = student.id;
      document.getElementById("f-roll_number").value = student.roll_number;
      document.getElementById("f-name").value = student.name;
      document.getElementById("f-email").value = student.email;
      document.getElementById("f-phone_number").value = student.phone_number;
      document.getElementById("f-department").value = student.department;
      document.getElementById("f-year").value = student.year;
      document.getElementById("f-address").value = student.address || "";
    } else {
      el.modalTitle.textContent = "Add student";
      el.studentIdField.value = "";
    }

    el.modalOverlay.hidden = false;
    document.getElementById("f-roll_number").focus();
  }

  function closeModal() {
    el.modalOverlay.hidden = true;
  }

  function clearFormErrors() {
    for (const field of FIELD_IDS) {
      const span = el.form.querySelector(`[data-error-for="${field}"]`);
      if (span) span.textContent = "";
    }
  }

  function setFieldError(field, message) {
    const span = el.form.querySelector(`[data-error-for="${field}"]`);
    if (span) span.textContent = message;
  }

  function validateClientSide(payload) {
    const errors = {};

    if (!payload.roll_number) errors.roll_number = "Roll number is required.";
    if (!payload.name || payload.name.trim().length < 2) {
      errors.name = "Enter the student's full name.";
    } else if (!/^[A-Za-z .'-]+$/.test(payload.name)) {
      errors.name = "Only letters, spaces, and . ' - are allowed.";
    }
    if (!/^\S+@\S+\.\S+$/.test(payload.email)) errors.email = "Enter a valid email address.";
    if (!/^\d{10}$/.test(payload.phone_number)) errors.phone_number = "Phone number must be exactly 10 digits.";
    if (!payload.department) errors.department = "Select a department.";
    if (!payload.year) errors.year = "Select a year.";

    return errors;
  }

  async function handleSubmit(e) {
    e.preventDefault();
    clearFormErrors();

    const payload = {
      roll_number: document.getElementById("f-roll_number").value.trim(),
      name: document.getElementById("f-name").value.trim(),
      email: document.getElementById("f-email").value.trim(),
      phone_number: document.getElementById("f-phone_number").value.trim(),
      department: document.getElementById("f-department").value,
      year: Number(document.getElementById("f-year").value),
      address: document.getElementById("f-address").value.trim(),
    };

    const clientErrors = validateClientSide(payload);
    if (Object.keys(clientErrors).length > 0) {
      for (const [field, message] of Object.entries(clientErrors)) setFieldError(field, message);
      return;
    }

    const id = el.studentIdField.value;
    const isEdit = Boolean(id);
    const url = isEdit ? `${API_BASE}${id}/` : API_BASE;
    const method = isEdit ? "PUT" : "POST";

    try {
      const response = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (response.status === 400) {
        const errors = await response.json();
        for (const [field, messages] of Object.entries(errors)) {
          setFieldError(field, Array.isArray(messages) ? messages[0] : String(messages));
        }
        return;
      }

      if (!response.ok) throw new Error(`Server responded ${response.status}`);

      closeModal();
      showBanner("success", isEdit ? "Student record updated." : "Student added to the registry.");
      fetchStudents();
    } catch (err) {
      showBanner("error", "Couldn't save the record. Please try again.");
    }
  }

  // ---- delete confirmation ----

  function openConfirm(student) {
    pendingDeleteId = student.id;
    el.confirmBody.textContent = `${student.name} (${student.roll_number}) will be permanently removed.`;
    el.confirmOverlay.hidden = false;
  }

  function closeConfirm() {
    el.confirmOverlay.hidden = true;
    pendingDeleteId = null;
  }

  async function performDelete() {
    if (!pendingDeleteId) return;
    try {
      const response = await fetch(`${API_BASE}${pendingDeleteId}/`, { method: "DELETE" });
      if (!response.ok) throw new Error(`Server responded ${response.status}`);
      closeConfirm();
      showBanner("success", "Student record removed.");
      fetchStudents();
    } catch (err) {
      showBanner("error", "Couldn't remove the record. Please try again.");
    }
  }

  // ---- banner ----

  function showBanner(type, message) {
    el.banner.textContent = message;
    el.banner.className = `banner banner--${type}`;
    el.banner.hidden = false;
    clearTimeout(bannerTimeout);
    bannerTimeout = setTimeout(() => {
      el.banner.hidden = true;
    }, 4000);
  }

  document.addEventListener("DOMContentLoaded", init);
})();
