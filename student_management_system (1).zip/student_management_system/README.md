# Student Management System

A full-stack CRUD web application for managing student enrollment records.
Built with a vanilla HTML/CSS/JS frontend, a Django REST Framework backend,
and an SQLite database.

## Tech stack

| Layer        | Technology                     |
|--------------|---------------------------------|
| Frontend     | HTML, CSS, JavaScript (fetch API) |
| Backend      | Django 6.1 + Django REST Framework |
| Database     | SQLite                          |
| API testing  | Postman                         |

## Folder structure

```
student_management_system/
├── backend/
│   ├── manage.py
│   ├── requirements.txt
│   ├── config/            # Django project settings & URLs
│   └── students/          # App: models, serializers, views, tests
├── frontend/
│   ├── index.html
│   ├── style.css
│   └── script.js
├── postman_collection.json
└── README.md
```

The frontend is served directly by Django (no separate frontend server, no
CORS to configure) — one command runs the whole app.

## Setup and execution

1. **Create a virtual environment** (recommended) and activate it:
   ```
   python -m venv venv
   source venv/bin/activate      # Windows: venv\Scripts\activate
   ```

2. **Install dependencies:**
   ```
   cd backend
   pip install -r requirements.txt
   ```

3. **Apply database migrations:**
   ```
   python manage.py migrate
   ```

4. **Run the development server:**
   ```
   python manage.py runserver
   ```

5. **Open the app:** visit `http://127.0.0.1:8000/` in your browser. The page
   loads the student list, and you can add, edit, search, filter, and delete
   records from there.

### Optional: admin panel

To browse/edit records through Django's built-in admin as well:
```
python manage.py createsuperuser
```
Then visit `http://127.0.0.1:8000/admin/` and log in.

## REST API reference

Base URL: `http://127.0.0.1:8000/api/students/`

| Operation  | Method | Endpoint                | Notes                                   |
|------------|--------|--------------------------|------------------------------------------|
| Create     | POST   | `/students/`             | JSON body, see fields below              |
| Read all   | GET    | `/students/`             | Supports `?search=`, `?department=`, `?year=` |
| Read one   | GET    | `/students/{id}/`        |                                           |
| Update     | PUT    | `/students/{id}/`        | Full record replace                      |
| Delete     | DELETE | `/students/{id}/`        |                                           |

**Student fields:**

| Field          | Type   | Rules                                              |
|----------------|--------|-----------------------------------------------------|
| roll_number    | string | required, unique, stored uppercase                   |
| name           | string | required, letters/spaces/`. ' -` only               |
| email          | string | required, unique, valid email format                 |
| department     | string | required, one of CSE / ECE / EEE / MECH / CIVIL / IT |
| year           | int    | required, 1–4                                         |
| phone_number   | string | required, exactly 10 digits                           |
| address        | string | optional                                              |

Validation runs both in the browser (for instant feedback) and on the server
(Django REST Framework serializer) — the server is the source of truth even
if a request bypasses the UI.

## Testing

**Automated tests** (model + API, via Django's test runner):
```
cd backend
python manage.py test
```

**Manual API testing with Postman:**
1. Open Postman → Import → select `postman_collection.json`.
2. The collection is organized into Create / Read / Update / Delete folders,
   each including both valid requests and edge cases (missing fields,
   duplicate roll number, invalid phone number, invalid IDs).
3. Run "Create Student - valid" first and copy the returned `id` into the
   collection's `student_id` variable so the Update/Delete requests target
   a real record.

## Future enhancements

- Authentication (login-protected admin actions)
- Pagination for large student lists
- CSV export of the roster
- Bulk import from a spreadsheet
